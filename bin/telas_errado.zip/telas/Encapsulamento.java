package telas;

public class Encapsulamento {
	
	
	public void fechar_janela() {
		
        System.exit(0);

        //Para usar
        	/*  
        	 
        	  	Encapsulamento fechar = new Encapsulamento();
				fechar.fechar_janela(); 
			
			*/
        
		
	}
	public void tipo_pessoa() {
		
		String nome;
		String email;
		int idade;
		
		
	}

}
