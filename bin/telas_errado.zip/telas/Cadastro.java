package telas;

public class Cadastro {

	private String[] nome;
	private String[] data_de_nascimento;
	private String[] Email;
	private char genero;
	
	public String[] getNome() {
		return nome;
	}
	public void setNome(String[] nome) {
		this.nome = nome;
	}
	public String[] getData_de_nascimento() {
		return data_de_nascimento;
	}
	public void setData_de_nascimento(String[] data_de_nascimento) {
		this.data_de_nascimento = data_de_nascimento;
	}
	public String[] getEmail() {
		return Email;
	}
	public void setEmail(String[] email) {
		Email = email;
	}
	public char getGenero() {
		return genero;
	}
	public void setGenero(char genero) {
		this.genero = genero;
	}

	

}
