package telas;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class List_Usuarios {
    private Usuario[] listaUsuario;
    private int lastUsuario;
    private int vetor;
    
    private Set<String> loginsUsados; // Armazena logins já utilizados

    public List_Usuarios(int tamanhoMaximo) {
    	
        listaUsuario = new Usuario[tamanhoMaximo];
        lastUsuario = -1;
        loginsUsados = new HashSet<>();
        
    }

    public void add(Usuario novoUsuario) {
        if (lastUsuario + 1 < listaUsuario.length) {
            lastUsuario++;
            listaUsuario[lastUsuario] = novoUsuario;
        }else {
            // Aqui você pode tratar o caso de lista cheia, por exemplo, redimensionando a lista.
            // Ou lançar uma exceção ou retornar uma mensagem de erro, dependendo dos requisitos.
            System.err.println("A lista de usuários está cheia.");
        }
    }
    

    public int getIdUsuario(String login) {
        int idUsuario = -1;
        int aux = -1;
        while (aux < lastUsuario) {
            aux++;
            if (listaUsuario[aux].getLogin().equals(login)) {
                idUsuario = aux;
                break;
            }
        }
        return idUsuario;
    }

    private String gerarLoginUnico(String nome) {
        String login = nome.toLowerCase().replaceAll(" ", ""); // Gere um login a partir do nome
        int contador = 1;
        String loginOriginal = login;

        // Enquanto o login já estiver em uso, adicione um número ao final
        while (loginsUsados.contains(login)) {
            login = loginOriginal + contador;
            contador++;
        }

        // Marque o login como usado
        loginsUsados.add(login);

        return login;
    }

    public void showUsuarios() {
        for (int i = 0; i <= lastUsuario; i++) {
            System.out.println(i + " - " + listaUsuario[i].getLogin() + " - " + listaUsuario[i].getSenha() + " - " + listaUsuario[i].getEmail());
        }
        
       /*if(lastUsuario < 4) {
    	   System.out.println(listaUsuario[3]);
       }*/
    
    }

    public List<Usuario> getListaUsuarios() {
        List<Usuario> lista = new ArrayList<>();
        for (int i = 0; i <= lastUsuario; i++) {
            lista.add(listaUsuario[i]);
        }
        return lista;
    }



    
}
