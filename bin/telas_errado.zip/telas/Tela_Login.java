package telas;
import telas.Tela_Cadastro;
import telas.Home_admin;

import javax.swing.JFrame;
import javax.swing.JPanel;
import telas.Tela_Cadastro;
import telas.Encapsulamento;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.Cursor;

import telas.Dados_Perfil;

public class Tela_Login {

	//private static final Component Tela_Cadastro = null;
	public JFrame frame;
	private JTextField Campo_Email;
	private JPasswordField Campo_senha;
    static List_Usuarios list;
    static Usuario user;
    Home_admin home;
    Iniciar init;
    
    private static Home_admin homeadmin;
   // 
    
	//
    
	
	static String nome_para_tela;
    
    
    public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					Iniciar init = new Iniciar();
					
			//		Home_admin home = null;
					
	                Home_admin home = new Home_admin(init, null); // Certifique-se de passar a instância correta de Home_admin

					Tela_Login window = new Tela_Login(list, user, home, init);
					
					
					
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	
	 */
	public Tela_Login(List_Usuarios list, Usuario user, Home_admin home, Iniciar init) {
		this.list = list;
		this.user = user;
		this.homeadmin = home;
		
		initialize();
		

	}
	
	
	public boolean fazerLogin(String email, String senha) {
        try {
            for (Usuario usuario : init.list.getListaUsuarios()) {
            	
         System.out.println("TESTE EMAIL:  "+usuario.getEmail());
         System.out.println("TESTE SENHA:  "+usuario.getSenha());
         if (usuario.getEmail().equals(email) && usuario.getSenha().equals(senha))   {
        	 nome_para_tela = init.user.getNome();
        	 
        	 
        //	 init.frame.dispose();
             return true; // Login bem-sucedido
         }
        
     }
     
       } catch (Exception e) {
          // Login falhou
       }
   
        return false;
   
	}

	
	private void initialize() {		
		
		frame = new JFrame();
		frame.getContentPane().setIgnoreRepaint(true);
		frame.setUndecorated(true);
		frame.getContentPane().setBackground(new Color(241, 241, 241));
		frame.setBackground(new Color(119, 118, 123));
		// Imagem do Programa assim que estiver sendo executavel 
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("/home/samuel/Pictures/Screenshot from 2023-08-19 09-58-19.jpg"));
		frame.setBounds(500, 250, 955, 586);
		
		
		// ESSA FUNÇÃO PARA DEIXAR A TELAS MAXIMIZADA
        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JLabel lblPhotofatec = new JLabel("Photo_fatec");
		lblPhotofatec.setBackground(new Color(241, 241, 241));
		lblPhotofatec.setIgnoreRepaint(true);
		lblPhotofatec.setIcon(new ImageIcon("/home/samuel/eclipse-workspace/Sistema_Protótico/src/Imagens/photo_system.png"));
		lblPhotofatec.setBounds(0, 62, 544, 380);
		frame.getContentPane().add(lblPhotofatec);
		
		Campo_Email = new JTextField();
		Campo_Email.setFont(new Font("FreeSans", Font.BOLD, 16));
		Campo_Email.setBorder(null);
		Campo_Email.setBackground(new Color(246, 246, 246));
		Campo_Email.setAutoscrolls(false);
		Campo_Email.setCaretColor(Color.DARK_GRAY);
		Campo_Email.setBounds(609, 172, 255, 24);
		frame.getContentPane().add(Campo_Email);
		Campo_Email.setColumns(10);
		
		
		Campo_senha = new JPasswordField();
		Campo_senha.setFont(new Font("Dialog", Font.BOLD, 15));
		Campo_senha.setAutoscrolls(false);
		Campo_senha.setBackground(new Color(246, 246, 246));
		Campo_senha.setBorder(null);
		Campo_senha.setSelectionColor(new Color(184, 207, 229)); 
		Campo_senha.setBounds(605, 260, 255, 24);
		frame.getContentPane().add(Campo_senha);
		
		JLabel lblMostrarsenha = new JLabel("");
		lblMostrarsenha.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblMostrarsenha.setIcon(new ImageIcon("/home/samuel/Desktop/.Ocultar_senha.png"));
		lblMostrarsenha.setBounds(614, 302, 237, 35);
		frame.getContentPane().add(lblMostrarsenha);
		
		JLabel lblmostrar_senha_ativado = new JLabel("hhh");
		lblmostrar_senha_ativado.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblmostrar_senha_ativado.setIcon(new ImageIcon("/home/samuel/Desktop/.Mostrar_senha.png"));
		lblmostrar_senha_ativado.setBounds(614, 305, 200, 28);
		frame.getContentPane().add(lblmostrar_senha_ativado);
		lblmostrar_senha_ativado.setVisible(false);
		
		JButton btnFecharjanela = new JButton("");
		btnFecharjanela.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnFecharjanela.setBorderPainted(false);
		btnFecharjanela.setRequestFocusEnabled(false);
		btnFecharjanela.setRolloverEnabled(false);
		btnFecharjanela.setContentAreaFilled(false);
		btnFecharjanela.setFont(new Font("Dialog", Font.BOLD, 10));
		btnFecharjanela.setBounds(915, 0, 20, 27);
		frame.getContentPane().add(btnFecharjanela);
		btnFecharjanela.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
				//fechar_janela();
			Encapsulamento fechar = new Encapsulamento();
			
	        int escolha = JOptionPane.showOptionDialog(
	                null,
	                "Deseja fechar o Programa?",
	                "Você tem Certeza?",
	                JOptionPane.OK_CANCEL_OPTION,
	                JOptionPane.WARNING_MESSAGE,
	                null,
	                new Object[]{"Sim", "Voltar para Programa"}, // Opções para o usuário
	                "Sim" // Opção padrão selecionada
	            );
			
	        	if(escolha == 0) {
	        		
	        		
	        		fechar.fechar_janela();
	        	}
			
			}
		});
		
				
				JButton btnNewButton = new JButton("");
				btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				btnNewButton.setBorderPainted(false);
				btnNewButton.setContentAreaFilled(false);
				btnNewButton.setAutoscrolls(true);
				btnNewButton.setForeground(new Color(250, 240, 230));
				btnNewButton.setIcon(null);
				btnNewButton.setBackground(new Color(220, 20, 60));
				btnNewButton.setFont(new Font("Dialog", Font.BOLD, 16));
				//btnNewButton.setVisible(false);
				btnNewButton.addActionListener(new ActionListener() {
					


					//Ação do botãoEntrar
					public void actionPerformed(ActionEvent e) {
				        int i = 0;
				        int vazio = 0;
				        int nulo = 0;
						
						
						
						String comparacao_email = Campo_Email.getText();
						String senhaTexto = new String(Campo_senha.getPassword());

						
						
						if(fazerLogin(comparacao_email, senhaTexto)) {
							System.out.println("CONSEGUIMOS");
							//init.frame.dispose();
							
							
								
						//	homeadmin.main(null);
							
							homeadmin.frame.setVisible(true);
							
							frame.setVisible(false);
							
						//	frame.dispose();
							
							nulo = 30;
							
							
						}else {
							//init.frame.dispose();
							System.out.println("Infelizmente não foi dessa vez");
							//nulo = 10;
						}
					        

						 
						 Usuario_2 usuarioObj = new Usuario_2();
					        String[] usuarios = usuarioObj.getUsuario();
					        String[] senha = usuarioObj.getSenha();
					        

					        
					        
					        //read = new Scanner(System.in);
					        
					        //System.out.print("Login: ");
					        //String buscar = read.nextLine();
					        if(nulo != 30) {
							        for (i = 0; i < usuarios.length; i++) {
							           
							        	nulo = nulo + 1;
							        	
							        	if (usuarios[i].equals(Campo_Email.getText())) {
							                
							     			        		
							        		
							                if((senha[i].equals(senhaTexto))){
							                
							                	
																								
												//homeadmin.main(null);
												
												//homeadmin.frame.setVisible(true);
												
												homeadmin.frame.setVisible(true);
												
												frame.setVisible(false);
												
												//frame.setVisible(false);
												
												//frame.dispose();
	
							                	nulo = 0;
							                	
							                	System.out.println("Você acertou o pré cadastrado");
							                			
							                }else {
							            	  //JOptionPane.showMessageDialog(null,"Usuário ou senha inválidos");
							            	  nulo = 10;
							            	  break;
							                }

							        	}
					        	
					        	}		
					
					        }
					        	
					        if(comparacao_email == null || comparacao_email.trim().equals("")) {
					        	vazio = vazio + 10;			    
					        	nulo = 0;
							}
					        if(senhaTexto == null || senhaTexto.trim().equals("")) {
					        	vazio = vazio + 20;		
					        	nulo = 0;
							}			        
					        if(vazio == 10) {
					        	//JOptionPane.showMessageDialog(null,"Campo de Email vazio");
								JOptionPane.showMessageDialog(null,"Campo de Email vazio","Alerta",JOptionPane.WARNING_MESSAGE);

					        	
					        }
					        if(vazio == 20) {
					        	//JOptionPane.showMessageDialog(null,"Campo de Senha vazio");
								JOptionPane.showMessageDialog(null,"Campo do Senha vazio","Alerta",JOptionPane.WARNING_MESSAGE);

					        	
					        }			        
					        if(vazio == 30) {
					        	//JOptionPane.showMessageDialog(null,"Campos Email e Senha vazios");
								JOptionPane.showMessageDialog(null,"Campos de Email e Senha vazios","Alerta",JOptionPane.WARNING_MESSAGE);

					        }
					        if(nulo == 10) {
					        	//JOptionPane.showMessageDialog(null,"Usuário ou Senha Inválidos");
								JOptionPane.showMessageDialog(null,"Usuário ou Senha Inválidos","Alerta",JOptionPane.ERROR_MESSAGE);

					        }
					        
						
						
						/*
						
						if((comparacao_email.equals(email)) && (senhaTexto.equals(senha))) {
							
							
							
							System.out.println("Certo");
							
						}else{
							System.out.println("Errado!!! ");
					
					}*/
				}
});
				
	

		btnNewButton.setBounds(665, 369, 139, 38);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnCadastrar = new JButton("");
		btnCadastrar.setBorder(null);
		btnCadastrar.setContentAreaFilled(false);
		btnCadastrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		btnCadastrar.setBounds(668, 439, 129, 38);
		frame.getContentPane().add(btnCadastrar);
		btnCadastrar.setFont(new Font("Dialog", Font.BOLD, 12));
		
		btnCadastrar.addActionListener(new ActionListener() {
			
			//Ação do botão Cadastrar
			public void actionPerformed(ActionEvent e) {
				
			
			Tela_Cadastro main = new Tela_Cadastro(list);
			//System.out.println("Voce digitou");
			//Tela_Cadastro.main(null);
			//frame.dispose();
			main.frame.setVisible(true);
			
	        frame.setVisible(false); // Oculta a tela principal
	        

		
			}
			}) ;
		
		
		JRadioButton rdbtnMostrarSenha = new JRadioButton("");
		rdbtnMostrarSenha.setFocusable(false);
		rdbtnMostrarSenha.setFocusPainted(false);
		rdbtnMostrarSenha.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		rdbtnMostrarSenha.setContentAreaFilled(false);
		rdbtnMostrarSenha.setMinimumSize(new Dimension(30, 30));
		rdbtnMostrarSenha.setMaximumSize(new Dimension(40, 40));
		rdbtnMostrarSenha.setActionCommand("");
		rdbtnMostrarSenha.setFont(new Font("Dialog", Font.BOLD, 11));
		rdbtnMostrarSenha.setBounds(626, 310, 171, 21);
		frame.getContentPane().add(rdbtnMostrarSenha);
		rdbtnMostrarSenha.addActionListener(new ActionListener() {
			
			//Ação do RadioButtom para ocultar o que sai do texto password
			public void actionPerformed(ActionEvent e) {
				 JRadioButton checkBox = (JRadioButton) e.getSource();
	                Campo_senha.setEchoChar(checkBox.isSelected() ? '\u0000' : '•');
	                
	                if (checkBox.isSelected()) {
	                    lblmostrar_senha_ativado.setVisible(true);
	                    lblMostrarsenha.setVisible(false);
	                } else {
	                    lblmostrar_senha_ativado.setVisible(false);
	                    lblMostrarsenha.setVisible(true);
	                }
		
			}
				}) ;
		
		
		JLabel lblHhh_1 = new JLabel("");
		lblHhh_1.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		lblHhh_1.setIcon(new ImageIcon("/home/samuel/Desktop/.Tela_Login.png"));
		lblHhh_1.setBounds(483, 40, 595, 498);
		frame.getContentPane().add(lblHhh_1);
		
		JLabel arch = new JLabel("New label");
		arch.setIcon(new ImageIcon("/home/samuel/eclipse-workspace/Sistema_Protótico/src/Imagens/Screenshot from 2023-08-19 15-51-08.png"));
		arch.setBounds(567, 56, 428, 399);
		frame.getContentPane().add(arch);
		
		JLabel lblHhh = new JLabel("");
		lblHhh.setIcon(new ImageIcon("/home/samuel/Downloads/X_vermelho-removebg-preview_resized.png"));
		lblHhh.setBounds(911, -8, 26, 43);
		frame.getContentPane().add(lblHhh);

		
	}
	
	public void fecharTela() {
		frame.setVisible(true);
	}
	
	
	
	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
