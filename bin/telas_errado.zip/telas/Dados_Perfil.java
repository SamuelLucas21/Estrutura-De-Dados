package telas;

public class Dados_Perfil {
	
	static String nome;
	public static String getNome() {
		return nome;
	}
	public static void setNome(String nome) {
		Dados_Perfil.nome = nome;
	}
	static String senha;
	
	
}
