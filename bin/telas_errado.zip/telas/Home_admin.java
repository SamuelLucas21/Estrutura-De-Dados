package telas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.UIManager;
import javax.swing.JScrollPane;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;

import telas.Tela_Login;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import telas.Publicar;
import javax.swing.JTextField;


public class Home_admin {
	
	static List_Usuarios list;
	static Iniciar init = new Iniciar();
	
	static Usuario user;
	static Home_admin home;
	Tela_Login login = new Tela_Login(list, user, home, init);
	
	public JFrame frame;
		
	Dados_Perfil dados = new Dados_Perfil();
	
//	ArrayList<String> mensagens = new ArrayList<>();
	
	

	public static void main(String [] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
	                //List_Usuarios list = new List_Usuarios();
	                Iniciar init = new Iniciar();

	                // Crie uma instância de Tela_Login antes de criar Home_admin
	                Tela_Login login = new Tela_Login(list, null, null, init);
					
					Home_admin window = new Home_admin(init, login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	JTextArea textArea = new JTextArea();
	JLabel lblDesfocado = new JLabel("Desfocado");


	public Home_admin(Iniciar init, Tela_Login login) {
		
		//login.setVisible(false);
		
		
		//this.login = login;
		this.init = init;
		
		initialize();
		
		
		//textArea = new JTextArea();
		// Inicialize o texto vazio
	

	}

	
	
	
	public void addMensagem(String me) {
		
		
		init.mensagens.add(me);
		
	}
	

	
	

	
	private void initialize() {
		
		
		frame = new JFrame();
		frame.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				
			}
		});
		
		this.textArea = textArea;
		
		textArea.setBounds(280, 128, 622, 570); // Defina os limites após a inicialização
		//JScrollPane scrollPane = new JScrollPane();
		//scrollPane.setBounds(280, 128, 622, 570);
	//	frame.getContentPane().add(scrollPane);
		//scrollPane.setViewportView(textArea);
		
		textArea.setEditable(false);
		textArea.setBounds(280, 128, 622, 570);									//	----------------------------
		frame.getContentPane().add(textArea);
		textArea.setText(""); 
		//JScrollPane scrollPane = new JScrollPane();
		//scrollPane.setBounds(280, 128, 622, 570);
		
		

		
		
		frame.getContentPane().setIgnoreRepaint(true);
		frame.setUndecorated(true);
		frame.getContentPane().setBackground(new Color(241, 241, 241));
		frame.setBackground(new Color(119, 118, 123));
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("/home/samuel/Pictures/Screenshot from 2023-08-19 09-58-19.jpg"));
		frame.setBounds(350, 150, 1250, 760);
		
		
		//Para Desktop
		//frame.setBounds(100, 70, 1250, 760);
		
		// ESSA FUNÇÃO PARA DEIXAR A TELAS MAXIMIZADA
        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

		
		JButton buttonPerfil = new JButton("");
		buttonPerfil.setBounds(12, 128, 123, 33);
		buttonPerfil.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		buttonPerfil.setContentAreaFilled(false);
		buttonPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	        	JOptionPane.showMessageDialog(null,"Botão Perfil");
	        	
	        	
				
			}
		});
		frame.getContentPane().setLayout(null);
				
				
				
		
		
		buttonPerfil.setFocusPainted(false);
		buttonPerfil.setFocusTraversalKeysEnabled(false);
		buttonPerfil.setFocusable(false);
		buttonPerfil.setBorder(null);
		frame.getContentPane().add(buttonPerfil);
		
		JButton btnPublication = new JButton("");
		btnPublication.setBounds(12, 188, 189, 27);
		btnPublication.setBorder(null);
		btnPublication.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Botão Publicações");
				
			}
		});
		
		//JTextArea textArea_1 = new JTextArea();
		
		//frame.getContentPane().add(textArea_1);
		
		
		btnPublication.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnPublication.setContentAreaFilled(false);
		frame.getContentPane().add(btnPublication);
		
		JButton btnSalvos = new JButton("");
		btnSalvos.setBounds(19, 349, 123, 33);
		btnSalvos.setBorder(null);
		btnSalvos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Botão Publicações");
				
			}
		});
		
		
		btnSalvos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSalvos.setContentAreaFilled(false);
		frame.getContentPane().add(btnSalvos);
		
		
		
		
		
		
		JButton btnChat = new JButton("");
		btnChat.setBounds(17, 241, 99, 33);
		btnChat.setBorder(null);
		btnChat.setContentAreaFilled(false);
		btnChat.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		frame.getContentPane().add(btnChat);
		
		JButton btnAmigos = new JButton("");
		btnAmigos.setBounds(15, 294, 129, 33);
		btnAmigos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		
		
		btnAmigos.setBorder(null);
		btnAmigos.setContentAreaFilled(false);
		btnAmigos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		frame.getContentPane().add(btnAmigos);
		
		JButton btnSair = new JButton("");
		btnSair.setBounds(19, 405, 92, 32);
		btnSair.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSair.setContentAreaFilled(false);
		btnSair.setBorder(null);
		frame.getContentPane().add(btnSair);
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
		        int escolha = JOptionPane.showOptionDialog(
		                null,
		                "Deseja fazer Log Off?",
		                "Você tem Certeza?",
		                JOptionPane.OK_CANCEL_OPTION,
		                JOptionPane.WARNING_MESSAGE,
		                null,
		                new Object[]{"Sim", "Voltar para Programa"}, // Opções para o usuário
		                "Sim" // Opção padrão selecionada
		            );
				
		        	if(escolha == 0) {
		        		
		        		frame.setVisible(false);
			        	JOptionPane.showMessageDialog(null,"Log Off Realizado com Sucesso!", "Aviso!", JOptionPane.INFORMATION_MESSAGE);
			        	
			        	//Tela_Login.main(null);
			        	
			        	login.fecharTela();
			        	
			        	
	
		        	}

			}
		});
		
		
		
		
		JButton btnPublic = new JButton("");
		btnPublic.setBounds(710, 87, 166, 38);
		
		
		
		btnPublic.setContentAreaFilled(false);
		btnPublic.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		frame.getContentPane().add(btnPublic);
		
		JButton btnVejamais = new JButton("");
		btnVejamais.setBounds(1008, 622, 143, 33);
		btnVejamais.setBorder(null);
		btnVejamais.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnVejamais.setContentAreaFilled(false);
		frame.getContentPane().add(btnVejamais);
		
		
		lblDesfocado.setIcon(new ImageIcon("/home/samuel/Downloads/Home_desfocada.png"));
		lblDesfocado.setBounds(0, -11, 1248, 782);
		frame.getContentPane().add(lblDesfocado);
		lblDesfocado.setVisible(false);
		
	
		
		btnPublic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					Publicar p = new Publicar(Home_admin.this, init);
					p.main(null);
					
					lblDesfocado.setVisible(true);
					frame.setEnabled(false);
					
					
					//frame.dispose();
				
			}
		});
		
		//JTextArea textArea_1 = new JTextArea();
		;										//	---------------------------
		
		
		
	//	textArea.setText(dados.getNome() + ":\n\t");
	//	textArea.setText(Publicar.publicacao);
	//	textArea.setText(getPublicou());
		
		
		
		
		
		JLabel lbladdFoto = new JLabel("");
		lbladdFoto.setBounds(1138, -3, 70, 81);
		lbladdFoto.setIcon(new ImageIcon("/home/samuel/Pictures/Screenshots/addFoto.png"));
		frame.getContentPane().add(lbladdFoto);
		

		
		
	
		JLabel lblNome_do_usuario = new JLabel(dados.getNome());
		lblNome_do_usuario.setBounds(1047, 23, 120, 27);
		frame.getContentPane().add(lblNome_do_usuario);
		
		
		
		JLabel lblBotes = new JLabel("");
		lblBotes.setBounds(-3, 112, 223, 336);
		lblBotes.setBorder(null);
		lblBotes.setIcon(new ImageIcon("/home/samuel/Pictures/Screenshots/Screenshot from 2023-10-01 21-00-43.png"));
		frame.getContentPane().add(lblBotes);
		
		JLabel lblPublic = new JLabel("");
		lblPublic.setBounds(705, 77, 196, 55);
		lblPublic.setIcon(new ImageIcon("/home/samuel/Pictures/Screenshots/Screenshot from 2023-10-01 21-24-51.png"));
		frame.getContentPane().add(lblPublic);
		
		JLabel lblPanel = new JLabel("");
		lblPanel.setBounds(268, 61, 632, 707);
		lblPanel.setIcon(new ImageIcon("/home/samuel/Pictures/Screenshots/Screenshot from 2023-10-01 21-02-51.png"));
		frame.getContentPane().add(lblPanel);
		
		JLabel labelAvisos = new JLabel("");
		labelAvisos.setBounds(937, 140, 290, 548);
		labelAvisos.setIcon(new ImageIcon("/home/samuel/Pictures/Screenshots/Screenshot from 2023-10-01 21-05-26.png"));
		frame.getContentPane().add(labelAvisos);
		
		JLabel lblLogofatec = new JLabel("");
		lblLogofatec.setBounds(2, 1, 1275, 75);
		lblLogofatec.setIcon(new ImageIcon("/home/samuel/Pictures/Screenshots/Screenshot from 2023-10-01 23-25-09.png"));
		frame.getContentPane().add(lblLogofatec);
		
		
	//	textArea.setEditable(false);
	
	}
	
	public void Desembacar() {
		lblDesfocado.setVisible(false);
		frame.setEnabled(true);
	}
	
	

	
	  public void postagem() {
		  	
		    StringBuilder textoCompleto = new StringBuilder();
		   
		    for (String mensagem : init.mensagens) {
		    	textoCompleto.append("\n" + dados.getNome()).append(":");
		        textoCompleto.append("\n\t").append(mensagem); // Adicione cada mensagem com um prefixo "\n\t"
		    }
		    textArea.setText(textoCompleto.toString());
		    
	}
	

	public static void dispose() {
		// TODO Auto-generated method stub
		
	}
}

