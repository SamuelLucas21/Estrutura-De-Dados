package telas;

public class Usuario {
	
	public String nome;
	public String senha;
	public String email;
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Usuario(String nome, String senha) {
		// TODO Auto-generated constructor stub
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	
	// Irá retornar apenas o nome
	public String getLogin() {
		
		return nome;
	
	}



}
