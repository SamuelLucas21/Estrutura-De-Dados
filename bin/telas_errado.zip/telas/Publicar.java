package telas;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;

public class Publicar extends JDialog{
	
    private JFrame frame;
    // Defina o segundo argumento como false para tornar a janela não modal

    private static Home_admin homeadmin;
    private static Iniciar init;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
           
                	//Iniciar init = new Iniciar();
                	
                    Publicar window = new Publicar(homeadmin, init);
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
            }
        });
    }

    
    
    public Publicar(Home_admin homeadmin, Iniciar init) {
    	this.homeadmin = homeadmin;
    	this.init = init;
    	
    	
    	initialize();
    	
    
        
    }
    
    
   
 

    private void initialize() {
    	

    	
    	//frame.toFront();

    	
        frame = new JFrame();
        frame.getContentPane().setFocusTraversalKeysEnabled(false);
        frame.setBounds(600, 300, 699, 458);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("/home/samuel/Pictures/Screenshot from 2023-08-19 09-58-19.jpg"));

        
        JButton btnFechar = new JButton("");
        btnFechar.setBorderPainted(false);
        btnFechar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        	     homeadmin.frame.setVisible(true);
                 homeadmin.Desembacar();
         		
                 frame.dispose(); 
        	}
        });
        
        
        btnFechar.setContentAreaFilled(false);
        btnFechar.setBorder(null);
        btnFechar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFechar.setBounds(664, 6, 19, 20);
        frame.getContentPane().add(btnFechar);
        
        JLabel lblHhh = new JLabel("");
        lblHhh.setIcon(new ImageIcon("/home/samuel/Downloads/X_vermelho-removebg-preview_resized.png"));
        lblHhh.setBounds(661, 0, 22, 31);
        frame.getContentPane().add(lblHhh);
		
		
        
        JLabel lblPublic = new JLabel("");
        lblPublic.setIcon(new ImageIcon("/home/samuel/Pictures/Screenshots/Screenshot from 2023-10-02 22-57-30.png"));
        lblPublic.setBounds(-7, -18, 730, 75);
        frame.getContentPane().add(lblPublic);

        JTextArea txtrEscrever = new JTextArea();
        txtrEscrever.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, new Color(0, 0, 0), null));
        txtrEscrever.setBackground(new Color(255, 255, 255));
        txtrEscrever.setFocusable(true);
        txtrEscrever.setText("Escrever...");
        txtrEscrever.setFont(new Font("Dialog", Font.PLAIN, 18));
        txtrEscrever.setBounds(12, 52, 675, 265);
        txtrEscrever.setForeground(Color.GRAY); 
        frame.getContentPane().add(txtrEscrever);
                
        
        JButton btnNewButton = new JButton("Publicar");
        btnNewButton.setContentAreaFilled(false);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {	
           		
        		String post = txtrEscrever.getText();
        		
        		
                //homeadmin.addMensagem(post);
                
                init.mensagens.add(post);
                
                homeadmin.postagem();
                
                
                homeadmin.frame.setVisible(true);
                homeadmin.Desembacar();
        		
                frame.dispose(); 
        		
        	
        	}
        });
        
        
        
        JButton btnPhoto = new JButton("photo");
        btnPhoto.setBounds(53, 390, 76, 56);
        frame.getContentPane().add(btnPhoto);
        btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnNewButton.setBounds(566, 421, 117, 25);
        frame.getContentPane().add(btnNewButton);


                JButton btnCancelar = new JButton("Cancelar");
                btnCancelar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                btnCancelar.addActionListener(new ActionListener() {
                	public void actionPerformed(ActionEvent e) {
                		
                	}
                });
                btnCancelar.setContentAreaFilled(false);
                btnCancelar.setBounds(437, 421, 117, 25);
                frame.getContentPane().add(btnCancelar);
                
                JButton btnFoco = new JButton("");
                btnFoco.setBorder(null);
                btnFoco.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                btnFoco.setContentAreaFilled(false);
                
                        
                        
                        btnFoco.setBounds(0, 0, 699, 458);
                        frame.getContentPane().add(btnFoco);
                
       
                btnFoco.addActionListener(new ActionListener() {
                	public void actionPerformed(ActionEvent e) {
                        frame.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseClicked(MouseEvent e) {
                                txtrEscrever.requestFocusInWindow();
                                
                                String obj = "";
						if(txtrEscrever.equals(null) || txtrEscrever.equals(obj)) {
                                	txtrEscrever.setText("Escrever...");
                                	txtrEscrever.setForeground(Color.GRAY);
                                	
                                }
                                
                                
                            }
                        });
                		
                		
                	}
                });
        frame.setUndecorated(true);
        
        txtrEscrever.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txtrEscrever.getText().equals("Escrever...")) {
                	txtrEscrever.setText("");
                	txtrEscrever.setForeground(Color.BLACK); // Altera a cor do texto para preto
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txtrEscrever.getText().isEmpty()) {
                	txtrEscrever.setText("Escrever...");
                	txtrEscrever.setForeground(Color.GRAY); // Restaura a cor do texto para cinza
                }
            }
        });
        
        

        txtrEscrever.requestFocusInWindow(); 
        
        // Adicionar um ouvinte de clique à JFrame para fazer a JTextArea perder o foco
        frame.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                txtrEscrever.requestFocusInWindow(); // Faz a JTextArea perder o foco
            }
        });

        // Adicionar um ouvinte de foco à JTextArea para limpar o texto quando selecionado
        txtrEscrever.addFocusListener(new FocusAdapter() {
            private boolean firstFocusGained = false;
            


            @Override
            public void focusGained(FocusEvent e) {
                if (!firstFocusGained) {
                    txtrEscrever.setText("");
                    firstFocusGained = true;
                }
            }
        });
    
    
    
    }
}
