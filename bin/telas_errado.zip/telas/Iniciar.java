package telas;

import java.awt.EventQueue;

import telas.Tela_Login;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

/*
 * Exception in thread "AWT-EventQueue-0" java.lang.NullPointerException: Cannot invoke "telas.List_Usuarios.getListaUsuarios()" because "telas.Tela_Cadastro.list" is null
	at telas.Tela_Cadastro$6.actionPerformed(Tela_Cadastro.java:10611)sa
 * 
 * 
 */


public class Iniciar {

	JFrame frame;
	

	
	static List_Usuarios list = new List_Usuarios(5);
	
	
	static ArrayList<String> mensagens = new ArrayList<>();
	
	
	static Usuario user;
	static Home_admin home;
	static Iniciar init;
	static Dados_Perfil dados;


	public static void main(String[] args) {
		
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
			
					
			//		Home_admin home = null;
					
			//		Usuario user = null;
					
					List_Usuarios list = new List_Usuarios(5);
					
					Tela_Login log = new Tela_Login(list, user, home, init);
					
					log.main(null);
					
					Dados_Perfil dados = new Dados_Perfil();
					
					//log.setVisible(true);
					
					
					
				//	frame.dispose();
					
				
					
					
					
					Iniciar window = new Iniciar();
					window.frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	
	
	
	
	
	public Iniciar() {
		
		
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnNewButton = new JButton("Iniciar");
		btnNewButton.setBounds(0, 0, 440, 270);
		btnNewButton.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {

				
			
			
			}
		});
		
		
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btnNewButton);
	}

}
